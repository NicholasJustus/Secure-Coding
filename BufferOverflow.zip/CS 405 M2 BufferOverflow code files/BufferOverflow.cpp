// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  bool input_too_long = false;

  std::cout << "Enter a value: ";

  // Limit input so it cannot exceed the buffer size.
  std::cin >> std::setw(sizeof(user_input)) >> user_input;

  // If extra input is still there, the user entered too much.
  // Clear it out and warn them.
  if (std::cin.peek() != '\n' && std::cin.peek() != EOF)
  {
    input_too_long = true;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  if (input_too_long)
  {
    std::cout << "Input was too long and was shortened to prevent a buffer overflow." << std::endl;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
