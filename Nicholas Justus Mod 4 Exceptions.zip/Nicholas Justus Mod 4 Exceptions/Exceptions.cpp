// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw a standard exception
    throw std::runtime_error("Error in application logic.");

    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Catch standard exceptions
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        std::cout << "Caught standard exception: "
            << ex.what()
            << std::endl;
    }

    // Throw custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Check for divide by zero
    if (den == 0)
    {
        throw std::runtime_error("Division by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    // Catch divide exception
    try
    {
        auto result = divide(numerator, denominator);

        std::cout << "divide("
            << numerator
            << ", "
            << denominator
            << ") = "
            << result
            << std::endl;
    }
    catch (const std::runtime_error& ex)
    {
        std::cout << "Division Error: "
            << ex.what()
            << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Catch exceptions from the application
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ex)
    {
        std::cout << "Custom Exception: "
            << ex.what()
            << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "Standard Exception: "
            << ex.what()
            << std::endl;
    }
    catch (...)
    {
        std::cout << "Unknown exception caught."
            << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu