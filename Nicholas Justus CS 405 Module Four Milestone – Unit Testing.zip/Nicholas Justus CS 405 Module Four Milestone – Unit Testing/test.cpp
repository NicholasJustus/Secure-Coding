// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart pointer to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // erase all elements in the collection, if any remain
        collection->clear();

        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);

        for (auto i = 0; i < count; ++i)
        {
            collection->push_back(rand() % 100);
        }
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
// CollectionTest::SetUp is called.
// Following this method (and all other TEST_F defined methods),
// CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

/* Commented out because it intentionally fails
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/

// Test adding one value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test adding five values to a collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5);
}

// Test max size is always greater than or equal to size
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(4);
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Test capacity is always greater than or equal to size
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(4);
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Test resize increases collection size
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    collection->resize(10);

    ASSERT_EQ(collection->size(), 10);
}

// Test resize decreases collection size
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    collection->resize(10);
    collection->resize(5);

    ASSERT_EQ(collection->size(), 5);
}

// Test resize decreases collection to zero
TEST_F(CollectionTest, ResizeToZero)
{
    collection->resize(10);
    collection->resize(0);

    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test clear erases collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);

    collection->clear();

    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test erase(begin,end) erases collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    add_entries(5);

    collection->erase(collection->begin(), collection->end());

    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Test reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    auto originalSize = collection->size();

    collection->reserve(50);

    EXPECT_GE(collection->capacity(), 50);
    EXPECT_EQ(collection->size(), originalSize);
}

// Negative test for out of range access
TEST_F(CollectionTest, OutOfRangeThrowsException)
{
    EXPECT_THROW(collection->at(1), std::out_of_range);
}

// Positive custom test
TEST_F(CollectionTest, FrontReturnsFirstElement)
{
    collection->push_back(10);
    collection->push_back(20);

    EXPECT_EQ(collection->front(), 10);
}

// Negative custom test
TEST_F(CollectionTest, EmptyVectorHasNoElements)
{
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}