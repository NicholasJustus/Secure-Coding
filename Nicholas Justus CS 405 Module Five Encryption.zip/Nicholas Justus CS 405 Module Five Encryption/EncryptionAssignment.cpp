// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // XOR encryption/decryption
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    std::ifstream input_file(filename);

    if (!input_file)
    {
        std::cerr << "Error opening file: " << filename << std::endl;
        return "";
    }

    std::stringstream buffer;
    buffer << input_file.rdbuf();

    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    size_t pos = string_data.find('\n');

    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(
    const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    std::ofstream output_file(filename);

    if (!output_file)
    {
        std::cerr << "Error creating file: " << filename << std::endl;
        return;
    }

    time_t now = time(nullptr);

    tm local_time;
#ifdef _WIN32
    localtime_s(&local_time, &now);
#else
    local_time = *localtime(&now);
#endif

    output_file << student_name << std::endl;

    output_file
        << (local_time.tm_year + 1900) << "-"
        << std::setw(2) << std::setfill('0') << (local_time.tm_mon + 1)
        << "-"
        << std::setw(2) << std::setfill('0') << local_time.tm_mday
        << std::endl;

    output_file << key << std::endl;

    output_file << data;

    output_file.close();
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";

    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    const std::string student_name = get_student_name(source_string);

    const std::string encrypted_string =
        encrypt_decrypt(source_string, key);

    save_data_file(
        encrypted_file_name,
        student_name,
        key,
        encrypted_string);

    const std::string decrypted_string =
        encrypt_decrypt(encrypted_string, key);

    save_data_file(
        decrypted_file_name,
        student_name,
        key,
        decrypted_string);

    std::cout
        << "Read File: "
        << file_name
        << " - Encrypted To: "
        << encrypted_file_name
        << " - Decrypted To: "
        << decrypted_file_name
        << std::endl;

    return 0;
}